    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package com.mycompany.project;

import static com.mycompany.project.director.DB_URL;
import static com.mycompany.project.director.PASSWORD;
import static com.mycompany.project.director.USERNAME;
import static com.mycompany.project.movie.DB_URL;
import static com.mycompany.project.movie.PASSWORD;
import static com.mycompany.project.movie.USERNAME;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class actor extends javax.swing.JInternalFrame {

    
     public static final String DB_URL = "jdbc:mysql://localhost/moviestudio";
      public static final String USERNAME = "ms";
        public static final String PASSWORD = "ms";
        
     DefaultTableModel modelactor,modelmovie;
    Object row [][];
    String col[] = {"ACTOR ID","MOVIE ID","FULL NAME","GENDER","NATIONALITY","AGE","CONTACT NUMBER","EMAIL ADDRESS"};
      Object row1[][];
    String col1[] = {"MOVIE ID","DIRECTOR ID","STUDIO ID","MOVIE TITTLE","CATEGORY","STATUS","PRICE"};
    public actor() {
        initComponents();
        setactortable();
        settable();
      
    }
    
    
   
    
    public void clear(){
        mi.setText("");
        ai.setText("");
        n.setText("");
        age.setText("");
       fn.setText("");
        cn.setText("");
        email.setText("");
buttonGroup1.clearSelection();
    }
    
    
     public void addactor(){
         if(mi.getText().equals("") || n.getText().equals("") || age.getText().equals("") || fn.getText().equals("") || cn.getText().equals("") || email.getText().equals("")){
             JOptionPane.showMessageDialog(null," PLEASE INPUT ALL FIELDS");
         }
         else{
        try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String gender;
            if(male.isSelected()){
                gender = " Male";
            }
            else{
              gender = "Female";
            }

            String sql = " insert into actor values(null,'"+Integer.parseInt(mi.getText())+"','"+fn.getText()+"','"+ gender +"','"+n.getText()+"','"+Integer.parseInt(age.getText())+"',"+cn.getText()+",'"+email.getText()+"')";
                    stmt.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"successfully added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
         }
    }
     
     
     public void setactortable(){
          modelactor = new DefaultTableModel(row, col);
        tablea.setModel(modelactor);  
          String sql = "select * from actor";
        try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                modelactor.addRow(new Object[]{rs.getInt("actor_id"),rs.getInt("movie_id"),rs.getString("name"),rs.getString("gender"),rs.getString("nationality"), rs.getInt("age"),rs.getString("number"),rs.getString("email")});
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
     }
    
    
      public void settable(){
     
        modelmovie = new DefaultTableModel(row1, col1);
        tablem.setModel(modelmovie);
        
         String sql = "SELECT * FROM movie";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                modelmovie.addRow(new Object []{rs.getInt("movie_id"),
                    rs.getInt("director_id"),
                    rs.getInt("studio_id"),
                    rs.getString("tittle"),
                    rs.getString("category"),
                    rs.getString("status"),
                    rs.getInt("price")});
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
}
      
      public void getactordata(){
           int rownumber = tablea.getSelectedRow();
             ai.setText(modelactor.getValueAt(rownumber , 0).toString());
             mi.setText(modelactor.getValueAt(rownumber , 1).toString());
             fn.setText(modelactor.getValueAt(rownumber , 2).toString());
             n.setText(modelactor.getValueAt(rownumber ,4).toString());
             age.setText(modelactor.getValueAt(rownumber , 5).toString());
             cn.setText(modelactor.getValueAt(rownumber ,6).toString());
             email.setText(modelactor.getValueAt(rownumber , 7).toString());
             
              String gender = modelactor.getValueAt(rownumber , 3).toString();
               if(gender.equals("Female")){
                   female.setSelected(true);
               }
               else{
                    male.setSelected(true);
               }
             
      }
      
      
       public void getmoviedata(){
         int rownumber = tablem.getSelectedRow();
         mi.setText(modelmovie.getValueAt(rownumber , 0).toString());
     }

        public void delete(){
            if(tablea.getSelectedRowCount()==1){
         try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "delete from actor where actor_id = '"+Integer.parseInt(ai.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"succesfully deleted");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
            }
             else{
               if(tablea.getSelectedRowCount() == 0){
                   JOptionPane.showMessageDialog(null,"please select single row to delete");
               }
               else{
                    JOptionPane.showMessageDialog(null,"table is empty");
               }
               }
    }
        
        
        
        public void update(){
        if(tablea.getSelectedRowCount()==1){
         String gender;
            if(male.isSelected()){
                gender = " Male";
            }
            else{
              gender = "Female";
            }
             try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "UPDATE actor SET name = '"+fn.getText()+"',"
                    + "gender = '"+gender+"',"
                    + "nationality = '"+n.getText()+"',"
                    + "age = '"+age.getText()+"',"
                     + "number = '"+cn.getText()+"',"
                    + " email = '"+email.getText()+"' WHERE actor_id = '"+Integer.parseInt(ai.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"updated added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        }
         else{
               if(tablea.getSelectedRowCount() == 0){
                   JOptionPane.showMessageDialog(null,"please select single row to delete");
               }
               else{
                    JOptionPane.showMessageDialog(null,"table is empty");
               }
               }
    }
       
       
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel36 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        save = new javax.swing.JButton();
        n = new javax.swing.JTextField();
        female = new javax.swing.JRadioButton();
        male = new javax.swing.JRadioButton();
        jLabel33 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        age = new javax.swing.JTextField();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        tablea = new javax.swing.JTable();
        jLabel34 = new javax.swing.JLabel();
        cn = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        mi = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        ai = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        email = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        tablem = new javax.swing.JTable();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        fn = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel36.setBackground(new java.awt.Color(255, 255, 255));
        jLabel36.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("CONTACT NO:");
        getContentPane().add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, -1, 22));

        jButton2.setText("clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 60, -1));

        save.setBackground(new java.awt.Color(0, 0, 0));
        save.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        save.setForeground(new java.awt.Color(204, 255, 255));
        save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/heroicons-solid--save (1).png"))); // NOI18N
        save.setText("SAVE");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        getContentPane().add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 220, -1));

        n.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nKeyTyped(evt);
            }
        });
        getContentPane().add(n, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 121, -1));

        buttonGroup1.add(female);
        female.setForeground(new java.awt.Color(255, 255, 255));
        female.setText("Female");
        getContentPane().add(female, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 130, -1, -1));

        buttonGroup1.add(male);
        male.setForeground(new java.awt.Color(255, 255, 255));
        male.setText("Male");
        getContentPane().add(male, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 130, -1, -1));

        jLabel33.setBackground(new java.awt.Color(255, 255, 255));
        jLabel33.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("NATIONALITY:");
        getContentPane().add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        jLabel30.setBackground(new java.awt.Color(0, 0, 0));
        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("ACTOR");
        getContentPane().add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 40));

        age.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ageKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ageKeyTyped(evt);
            }
        });
        getContentPane().add(age, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 180, 121, -1));

        jButton20.setBackground(new java.awt.Color(0, 0, 0));
        jButton20.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton20.setForeground(new java.awt.Color(255, 255, 255));
        jButton20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/mingcute--delete-fill.png"))); // NOI18N
        jButton20.setText("DELETE");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 220, -1));

        jButton21.setBackground(new java.awt.Color(0, 0, 0));
        jButton21.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 255, 255));
        jButton21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/dashicons--update.png"))); // NOI18N
        jButton21.setText("UPDATE");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 220, -1));

        tablea.setBackground(new java.awt.Color(204, 204, 204));
        tablea.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tablea.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablea.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableaMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tablea);

        getContentPane().add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 30, 750, 150));

        jLabel34.setBackground(new java.awt.Color(255, 255, 255));
        jLabel34.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("AGE:");
        getContentPane().add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 180, -1, 22));

        cn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cnKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cnKeyTyped(evt);
            }
        });
        getContentPane().add(cn, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, 121, -1));

        jLabel32.setBackground(new java.awt.Color(255, 255, 255));
        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("  GENDER:");
        getContentPane().add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, -1, -1));

        jLabel37.setBackground(new java.awt.Color(255, 255, 255));
        jLabel37.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("MOVIE ID:");
        getContentPane().add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        mi.setEditable(false);
        mi.setBackground(new java.awt.Color(153, 153, 153));
        getContentPane().add(mi, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 40, 122, -1));

        jLabel38.setBackground(new java.awt.Color(255, 255, 255));
        jLabel38.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("ACTOR ID:");
        getContentPane().add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, -1, -1));

        ai.setEditable(false);
        ai.setBackground(new java.awt.Color(153, 204, 255));
        ai.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                aiKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                aiKeyTyped(evt);
            }
        });
        getContentPane().add(ai, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, 122, -1));

        jLabel39.setBackground(new java.awt.Color(255, 255, 255));
        jLabel39.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("EMAIL ADRRESS:");
        getContentPane().add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, -1, 22));

        email.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                emailKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                emailKeyTyped(evt);
            }
        });
        getContentPane().add(email, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 240, 121, -1));

        tablem.setBackground(new java.awt.Color(204, 204, 204));
        tablem.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tablem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablemMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(tablem);

        getContentPane().add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 210, 750, 130));

        jLabel41.setBackground(new java.awt.Color(255, 255, 255));
        jLabel41.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("MOVIE TABLE");
        getContentPane().add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 190, -1, -1));

        jLabel42.setBackground(new java.awt.Color(255, 255, 255));
        jLabel42.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("ACTOR TABLE");
        getContentPane().add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 10, -1, -1));

        jLabel43.setBackground(new java.awt.Color(255, 255, 255));
        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("  FULLNAME:");
        getContentPane().add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 78, 22));

        fn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                fnKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                fnKeyTyped(evt);
            }
        });
        getContentPane().add(fn, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 100, 123, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\OIP (5).jpg")); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, 420));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\4441226.jpg")); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 830, 420));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
      addactor();
      setactortable();
      clear();
    }//GEN-LAST:event_saveActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
       delete();
       setactortable();
       clear();
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        update();
        setactortable();
        clear();
    }//GEN-LAST:event_jButton21ActionPerformed

    private void tableaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableaMouseClicked
      getactordata();
      ai.setEditable(false);
    }//GEN-LAST:event_tableaMouseClicked

    private void tablemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablemMouseClicked
      ai.setEditable(false);
        getmoviedata();
    }//GEN-LAST:event_tablemMouseClicked

    private void fnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fnKeyPressed
       
    }//GEN-LAST:event_fnKeyPressed

    private void nKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nKeyPressed
       
    }//GEN-LAST:event_nKeyPressed

    private void aiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_aiKeyPressed
      
    }//GEN-LAST:event_aiKeyPressed

    private void ageKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ageKeyPressed
       
    }//GEN-LAST:event_ageKeyPressed

    private void cnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnKeyPressed
        
    }//GEN-LAST:event_cnKeyPressed

    private void emailKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_emailKeyPressed
      
    }//GEN-LAST:event_emailKeyPressed

    private void aiKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_aiKeyTyped
          char c = evt.getKeyChar();
        
        if(Character.isDigit(c)){
            if(ai.getText().length()==11){
                evt.consume();
            }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_aiKeyTyped

    private void fnKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fnKeyTyped
     char c = evt.getKeyChar();
  
        
        if(Character.isLetter(c) || Character.isWhitespace(c) || c=='ñ' || c =='.' || c=='-'){
            
        }else{
              evt.consume(); 
        }
    }//GEN-LAST:event_fnKeyTyped

    private void nKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nKeyTyped
       char c = evt.getKeyChar();
  
        
        if(Character.isLetter(c) || Character.isWhitespace(c) || c=='ñ' || c =='.' || c=='-'){
            
        }else{
              evt.consume(); 
        }
    }//GEN-LAST:event_nKeyTyped

    private void ageKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ageKeyTyped
         char c = evt.getKeyChar();
        
        if(Character.isDigit(c)){
            if(age.getText().length()==3){
                evt.consume();
            }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_ageKeyTyped

    private void cnKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnKeyTyped
       char c = evt.getKeyChar();
        
        if(Character.isDigit(c)){
            if(cn.getText().length()==11){
                evt.consume();
            }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_cnKeyTyped

    private void emailKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_emailKeyTyped
        char c = evt.getKeyChar();
        if(Character.isDigit(c) || Character.isLetter(c) || c=='@' || c=='.' || c=='-' || c=='_'){

        }else{
            evt.consume();
        }
    }//GEN-LAST:event_emailKeyTyped

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       clear();
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField age;
    private javax.swing.JTextField ai;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField cn;
    private javax.swing.JTextField email;
    private javax.swing.JRadioButton female;
    private javax.swing.JTextField fn;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JRadioButton male;
    private javax.swing.JTextField mi;
    private javax.swing.JTextField n;
    private javax.swing.JButton save;
    private javax.swing.JTable tablea;
    private javax.swing.JTable tablem;
    // End of variables declaration//GEN-END:variables
}
