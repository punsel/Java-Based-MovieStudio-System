/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package com.mycompany.project;

import static com.mycompany.project.customer.DB_URL;
import static com.mycompany.project.customer.PASSWORD;
import static com.mycompany.project.customer.USERNAME;
import static com.mycompany.project.movie.DB_URL;
import static com.mycompany.project.movie.PASSWORD;
import static com.mycompany.project.movie.USERNAME;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class order extends javax.swing.JInternalFrame {

     public static final String DB_URL = "jdbc:mysql://localhost/moviestudio";
      public static final String USERNAME = "ms";
        public static final String PASSWORD = "ms";
    
    
   DefaultTableModel modelorder,modelcustomer,modelmovie;
    Object row [][];
    String col[] = {"CUSTOMER ID","MOVIE ID","ORDER ID","MOVIE PRICE","QUANTITY","ORDER DATE"};
    Object row1[][];
    String col1[] = {"MOVIE ID","DIRECTOR ID","STUDIO ID","MOVIE TITTLE","CATEGORY","STATUS","PRICE"};
     Object row2[][];
    String col2[] = {"CUSTOMER ID","NAME","GENDER","AGE","CONTACT NUMBER","EMAIL ADDRESS"};
  
    
    public order() {
        initComponents();
        initialstate();
        setordertable();
        setcustomertable();
        setmovietable();
    }
    
    
     public void initialstate(){
        save.setEnabled(false);
        
       q.setEditable(false);
    date.setEditable(false);
       
    }
    public void makeinput(){
         save.setEnabled(true);
       q.setEditable(true);
    date.setEditable(true);
    }
    
    public void clear(){
        ci.setText("");
         mi.setText("");
       oi.setText("");
       price.setText("");
        q.setText("");
        date.setText("");
    }
    
    public void input(){
       q.setEditable(true);
    date.setEditable(true);
    }
    
    
    
     public void addorder(){
         if(ci.getText().equals("") || mi.getText().equals("") || price.getText().equals("") || q.getText().equals("") || date.getText().equals("") ){
             JOptionPane.showMessageDialog(null," PLEASE INPUT ALL FIELDS");
         }
         else{
           try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();){
            
            String sql = "INSERT INTO orderr VALUES(null,'"+Integer.parseInt(mi.getText())+"','"+Integer.parseInt(ci.getText())+"','"+Double.parseDouble(price.getText())+"','"+Integer.parseInt(q.getText())+"','"+date.getText()+"')";
            
                    stmt.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"successfully added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
         }
    }
     
     public void setordertable(){
         
           modelorder = new DefaultTableModel(row, col);
        tableo.setModel(modelorder);
         
         
          String sql = "SELECT * FROM orderr";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                modelorder.addRow(new Object []{rs.getInt("customer_id"),
                      rs.getInt("movie_id"),
                    rs.getInt("order_id"),
                    rs.getDouble("price"),
                    rs.getString("quantity"),
                    rs.getString("date")
                }
                         
                );
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
     }
     
       public void setcustomertable(){
         
        modelcustomer = new DefaultTableModel(row2, col2);
        tablec.setModel(modelcustomer);
         
         
          String sql = "SELECT * FROM customer";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                 modelcustomer.addRow(new Object[]{rs.getInt("customer_id"),
                    rs.getString("name"),
                    rs.getString("gender"),
                    rs.getInt("age"),
                    rs.getString("number")
                        ,rs.getString("email")});
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
     }
     
     
    
      public void setmovietable(){
    
          modelmovie = new DefaultTableModel(row1, col1);
        tablem.setModel(modelmovie);
        
          String sql = "SELECT * FROM movie";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                modelmovie.addRow(new Object []{rs.getInt("movie_id"),
                    rs.getInt("director_id"),
                    rs.getInt("studio_id"),
                    rs.getString("tittle"),
                    rs.getString("category"),
                    rs.getString("status"),
                    rs.getDouble("price")});
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
}
      
       public void getcustomerdata(){
         int rownumber = tablec.getSelectedRow();
         
         ci.setText(modelcustomer.getValueAt(rownumber , 0).toString());   
     }
       
       
          public void getmoviedata(){
         int rownumber = tablem.getSelectedRow();
         mi.setText(modelmovie.getValueAt(rownumber , 0).toString());
         price.setText(modelmovie.getValueAt(rownumber , 6).toString());
        
         
     }
          
          
           public void getorderdata(){
         int rownumber = tableo.getSelectedRow();
         ci.setText(modelorder.getValueAt(rownumber , 0).toString());
          mi.setText(modelorder.getValueAt(rownumber , 1).toString());
           oi.setText(modelorder.getValueAt(rownumber ,2).toString());
           price.setText(modelorder.getValueAt(rownumber , 3).toString());
            q.setText(modelorder.getValueAt(rownumber ,4).toString());
             date.setText(modelorder.getValueAt(rownumber , 5).toString());
             
          
             
     }
           
              public void delete(){
                  if(tableo.getSelectedRowCount()== 1){
         try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "delete from orderr where order_id = '"+Integer.parseInt(oi.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"succesfully deleted");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
                  }
                   else{
               if(tableo.getSelectedRowCount() == 0){
                   JOptionPane.showMessageDialog(null,"please select single row to delete");
               }
               else{
                    JOptionPane.showMessageDialog(null,"table is empty");
               }
               }
    }
              
              
                  
    public void update(){
       if(tableo.getSelectedRowCount()==1){
             try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "UPDATE orderr SET  movie_id = '"+mi.getText()+"',"
                    +"customer_id = '"+ci.getText()+"',"
                    + "price = '"+price.getText()+"',"
                    + "quantity = '"+q.getText()+"',"
                    + " date= '"+date.getText()+"' WHERE order_id = '"+Integer.parseInt(oi.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"updated added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
       }
        else{
               if(tableo.getSelectedRowCount() == 0){
                   JOptionPane.showMessageDialog(null,"please select single row to update");
               }
               else{
                    JOptionPane.showMessageDialog(null,"table is empty");
               }
               }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jButton19 = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        tableo = new javax.swing.JTable();
        ci = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        q = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        price = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jButton20 = new javax.swing.JButton();
        save = new javax.swing.JButton();
        mi = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        oi = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        tablec = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        tablem = new javax.swing.JTable();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        date = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setText("clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, 60, -1));

        jButton21.setBackground(new java.awt.Color(0, 0, 0));
        jButton21.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 255, 255));
        jButton21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/dashicons--update.png"))); // NOI18N
        jButton21.setText("UPDATE");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 311, 200, 40));

        jLabel31.setBackground(new java.awt.Color(255, 255, 255));
        jLabel31.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("MOVIE ID:");
        getContentPane().add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 88, -1, -1));

        jLabel34.setBackground(new java.awt.Color(255, 255, 255));
        jLabel34.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("QUANTITY:");
        getContentPane().add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 169, -1, 22));

        jButton19.setBackground(new java.awt.Color(0, 0, 0));
        jButton19.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton19.setForeground(new java.awt.Color(255, 255, 255));
        jButton19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/typcn--plus (1).png"))); // NOI18N
        jButton19.setText("NEW");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton19, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, 100, 40));

        tableo.setBackground(new java.awt.Color(204, 204, 204));
        tableo.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tableo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tableo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableoMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tableo);

        getContentPane().add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 750, 88));

        ci.setEditable(false);
        ci.setBackground(new java.awt.Color(153, 153, 153));
        ci.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ciActionPerformed(evt);
            }
        });
        getContentPane().add(ci, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 55, 110, -1));

        jLabel33.setBackground(new java.awt.Color(255, 255, 255));
        jLabel33.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("MOVIE PRICE:");
        getContentPane().add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, 23));

        q.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                qKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                qKeyTyped(evt);
            }
        });
        getContentPane().add(q, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 169, 110, -1));

        jLabel35.setBackground(new java.awt.Color(255, 255, 255));
        jLabel35.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("CUSTOMER ID:");
        getContentPane().add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 60, -1, -1));

        price.setEditable(false);
        price.setBackground(new java.awt.Color(153, 153, 153));
        getContentPane().add(price, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, 110, -1));

        jLabel30.setBackground(new java.awt.Color(0, 0, 0));
        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("ORDER");
        getContentPane().add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jButton20.setBackground(new java.awt.Color(0, 0, 0));
        jButton20.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton20.setForeground(new java.awt.Color(255, 255, 255));
        jButton20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/typcn--plus (1).png"))); // NOI18N
        jButton20.setText("DELETE");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 200, -1));

        save.setBackground(new java.awt.Color(0, 0, 0));
        save.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        save.setForeground(new java.awt.Color(255, 255, 255));
        save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/heroicons-solid--save (1).png"))); // NOI18N
        save.setText("SAVE");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        getContentPane().add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 240, 100, 40));

        mi.setEditable(false);
        mi.setBackground(new java.awt.Color(153, 153, 153));
        getContentPane().add(mi, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 83, 110, -1));

        jLabel32.setBackground(new java.awt.Color(255, 255, 255));
        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("ORDER ID:");
        getContentPane().add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, -1, 20));

        oi.setEditable(false);
        oi.setBackground(new java.awt.Color(153, 204, 255));
        oi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                oiKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                oiKeyTyped(evt);
            }
        });
        getContentPane().add(oi, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, 110, -1));

        tablec.setBackground(new java.awt.Color(204, 204, 204));
        tablec.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tablec.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablec.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablecMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(tablec);

        getContentPane().add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 260, 750, 90));

        tablem.setBackground(new java.awt.Color(204, 204, 204));
        tablem.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tablem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablemMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(tablem);

        getContentPane().add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, 750, 90));

        jLabel36.setBackground(new java.awt.Color(255, 255, 255));
        jLabel36.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("MOVIE TABLE");
        getContentPane().add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 120, -1, -1));

        jLabel37.setBackground(new java.awt.Color(255, 255, 255));
        jLabel37.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("CUSTOMER TABLE");
        getContentPane().add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 240, -1, -1));

        jLabel38.setBackground(new java.awt.Color(255, 255, 255));
        jLabel38.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("ORDER DATE:");
        getContentPane().add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 203, -1, 22));
        getContentPane().add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 203, 110, -1));

        jLabel39.setBackground(new java.awt.Color(255, 255, 255));
        jLabel39.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("ORDER TABLE");
        getContentPane().add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 0, -1, -1));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\OIP (5).jpg")); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 370));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\4441226.jpg")); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, 830, 370));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
      
       setordertable();
       setmovietable();
        update();
       clear();
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        makeinput();
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
      delete();
      setordertable();
      clear();
    }//GEN-LAST:event_jButton20ActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
       addorder();
       setordertable();
       clear();
    }//GEN-LAST:event_saveActionPerformed

    private void tablecMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablecMouseClicked
     getcustomerdata();
    }//GEN-LAST:event_tablecMouseClicked

    private void tablemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablemMouseClicked

        getmoviedata();
    }//GEN-LAST:event_tablemMouseClicked

    private void tableoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableoMouseClicked
        getorderdata();
        makeinput();
    }//GEN-LAST:event_tableoMouseClicked

    private void ciActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ciActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ciActionPerformed

    private void oiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_oiKeyPressed
      
    }//GEN-LAST:event_oiKeyPressed

    private void qKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_qKeyPressed
       
    }//GEN-LAST:event_qKeyPressed

    private void oiKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_oiKeyTyped
         char c = evt.getKeyChar();
        
        if(Character.isDigit(c)){
            if(oi.getText().length()==11){
                evt.consume();
            }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_oiKeyTyped

    private void qKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_qKeyTyped
       char c = evt.getKeyChar();
        
        if(Character.isDigit(c)){
            if(q.getText().length()==11){
                evt.consume();
            }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_qKeyTyped

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       clear();
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ci;
    private javax.swing.JTextField date;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTextField mi;
    private javax.swing.JTextField oi;
    private javax.swing.JTextField price;
    private javax.swing.JTextField q;
    private javax.swing.JButton save;
    private javax.swing.JTable tablec;
    private javax.swing.JTable tablem;
    private javax.swing.JTable tableo;
    // End of variables declaration//GEN-END:variables
}
