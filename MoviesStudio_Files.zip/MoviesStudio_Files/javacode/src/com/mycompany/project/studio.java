/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package com.mycompany.project;

import javax.swing.table.DefaultTableModel;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class studio extends javax.swing.JInternalFrame {
 public static final String DB_URL = "jdbc:mysql://localhost/moviestudio";
  public static final String USERNAME = "ms";
   public static final String PASSWORD = "ms";
   DefaultTableModel modelstudio;
    Object row [][];
    String col[] = {"STUDIO ID","COMPANY NAME","COMPANY TYPE","CITY","DATE FOUNDED","FOUNDER"};
    public studio() {
        initComponents();
        initialstate();
        settable();
    }
    
    
    public void initialstate(){
        save.setEnabled(false);
        si.setEditable(false);
        cn.setEditable(false);
       cb.setEnabled(false);
        city.setEditable(false);
        date.setEditable(false);
        founder.setEditable(false);
    }
    public void makeinput(){
        save.setEnabled(true);
          cb.setEnabled(true);
        cn.setEditable(true);
        city.setEditable(true);
        date.setEditable(true);
        founder.setEditable(true);
    }
    
    public void clear(){
        si.setText("");
        cn.setText("");
      cb.setSelectedIndex(-1);
        city.setText("");
        date.setText("");
        founder.setText("");
    }
    
    public void input(){
       cb.setEnabled(true);
        cn.setEditable(true);
        city.setEditable(true);
        date.setEditable(true);
        founder.setEditable(true);
    }

    
    
    
     public void addstudio(){
         
         if(cn.getText().equals("") || city.getText().equals("") || date.getText().equals("") || founder.getText().equals("")){
             JOptionPane.showMessageDialog(null," PLEASE INPUT ALL FIELDS");
         }
         else{
             String type  = (String) cb.getItemAt(cb.getSelectedIndex());
             
         try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "INSERT INTO studio VALUES( null,'"+cn.getText()+"','"+type+"','"+city.getText()+"','"+date.getText()+"','"+founder.getText()+"')";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"NEW STUDIO ADDED!");
            clear();
        }catch(SQLException ex){
            ex.printStackTrace();
        }
         }
    }
     
     
      public void settable(){
      modelstudio = new DefaultTableModel(row, col);
        tables.setModel(modelstudio);
        
         String sql = "SELECT * FROM studio";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                modelstudio.addRow(new Object []{rs.getInt("studio_id"),rs.getString("company_name"),rs.getString("company_type"),rs.getString("city"),rs.getString("date"),rs.getString("founder")});
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
}
      
      
       public void getstudiodata(){
        int rowNumber = tables.getSelectedRow();
        si.setText(modelstudio.getValueAt(rowNumber,0).toString());
          cn.setText(modelstudio.getValueAt(rowNumber,1).toString());
            cb.setSelectedItem(modelstudio.getValueAt(rowNumber,2).toString());
              city.setText(modelstudio.getValueAt(rowNumber,3).toString());  
              date.setText(modelstudio.getValueAt(rowNumber,4).toString());
                founder.setText(modelstudio.getValueAt(rowNumber,5).toString());
              
    }
       
       
       
   
       public void delete(){
           if(tables.getSelectedRowCount() == 1){
         try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "delete from studio where studio_id = '"+Integer.parseInt(si.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"succesfully deleted");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
           }
           else{
               if(tables.getSelectedRowCount() == 0){
                   JOptionPane.showMessageDialog(null,"please select single row to delete");
               }
               else{
                    JOptionPane.showMessageDialog(null,"table is empty");
               }
               }
           }
    
     
       
       
       
    public void update(){
         if(tables.getSelectedRowCount() == 1){
              String type  = (String) cb.getItemAt(cb.getSelectedIndex());
             try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "UPDATE studio SET company_name = '"+cn.getText()+"',"
                    + "company_type = '"+type+"',"
                    + "city = '"+city.getText()+"',"
                    + "date = '"+date.getText()+"',"
                    + " founder = '"+founder.getText()+"' WHERE studio_id = '"+Integer.parseInt(si.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"updated added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
         }
            else{
               if(tables.getSelectedRowCount() == 0){
                   JOptionPane.showMessageDialog(null,"please select single row to update");
               }
               else{
                    JOptionPane.showMessageDialog(null,"table is empty");
               }
               }
    }
    
    
     
       
    
   
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        founder = new javax.swing.JTextField();
        si = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cb = new javax.swing.JComboBox<>();
        cn = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        city = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        date = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tables = new javax.swing.JTable();
        save = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        jButton1.setBackground(new java.awt.Color(204, 255, 255));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setText("STUDIO");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        setBackground(new java.awt.Color(51, 51, 51));
        setForeground(new java.awt.Color(204, 255, 255));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setText("clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 60, -1));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("STUDIO ID:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 78, -1, -1));

        founder.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                founderKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                founderKeyTyped(evt);
            }
        });
        jPanel2.add(founder, new org.netbeans.lib.awtextra.AbsoluteConstraints(83, 213, 130, -1));

        si.setBackground(new java.awt.Color(153, 204, 255));
        si.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                siKeyTyped(evt);
            }
        });
        jPanel2.add(si, new org.netbeans.lib.awtextra.AbsoluteConstraints(83, 73, 130, -1));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("COMPANY:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 106, -1, -1));

        cb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "Independent Film Studio", "Corporate Film Studio", "Corporate-Independent Film Studio" }));
        jPanel2.add(cb, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 130, 130, -1));

        cn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cnKeyTyped(evt);
            }
        });
        jPanel2.add(cn, new org.netbeans.lib.awtextra.AbsoluteConstraints(83, 101, 130, -1));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText(" TYPE:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 134, -1, -1));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("CITY:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 162, -1, -1));

        city.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cityKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cityKeyTyped(evt);
            }
        });
        jPanel2.add(city, new org.netbeans.lib.awtextra.AbsoluteConstraints(83, 157, 130, -1));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("DATE:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(36, 190, -1, -1));
        jPanel2.add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(83, 185, 130, -1));

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("FOUNDER:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 213, -1, -1));

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("  STUDIO ");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 20, 170, -1));

        tables.setBackground(new java.awt.Color(204, 204, 204));
        tables.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tables.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tables.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tables);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 40, 740, 300));

        save.setBackground(new java.awt.Color(0, 0, 0));
        save.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        save.setForeground(new java.awt.Color(204, 255, 255));
        save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/heroicons-solid--save (1).png"))); // NOI18N
        save.setText("SAVE");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        jPanel2.add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 240, 100, 40));

        jButton3.setBackground(new java.awt.Color(0, 0, 0));
        jButton3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/typcn--plus (1).png"))); // NOI18N
        jButton3.setText("NEW");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, 100, 40));

        jButton4.setBackground(new java.awt.Color(0, 0, 0));
        jButton4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/mingcute--delete-fill.png"))); // NOI18N
        jButton4.setText("DELETE");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 200, -1));

        jButton5.setBackground(new java.awt.Color(0, 0, 0));
        jButton5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/dashicons--update.png"))); // NOI18N
        jButton5.setText("UPDATE");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 200, -1));

        jLabel1.setText("jLabel1");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 0, 0));

        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\4441226.jpg")); // NOI18N
        jLabel10.setText("jLabel10");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, 830, 400));

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\OIP (5).jpg")); // NOI18N
        jLabel11.setText("jLabel11");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 400));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      
    }//GEN-LAST:event_jButton1ActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        addstudio();
        settable();
        
        
    }//GEN-LAST:event_saveActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      makeinput();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        delete();
        settable();
        clear();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       update();
       settable();
       clear();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void tablesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablesMouseClicked
      getstudiodata();
       input();
    }//GEN-LAST:event_tablesMouseClicked

    private void cnKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnKeyTyped
       char c = evt.getKeyChar();
  
        
        if(Character.isLetter(c) || Character.isWhitespace(c) || c=='ñ' || c =='.' || c=='-'){
            
        }else{
              evt.consume(); 
        }
    }//GEN-LAST:event_cnKeyTyped

    private void cityKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cityKeyPressed
       
    }//GEN-LAST:event_cityKeyPressed

    private void founderKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_founderKeyPressed
       
    }//GEN-LAST:event_founderKeyPressed

    private void cityKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cityKeyTyped
       char c = evt.getKeyChar();
  
        
        if(Character.isLetter(c) || Character.isWhitespace(c) || c=='ñ' || c =='.' || c=='-'){
            
        }else{
              evt.consume(); 
        }
    }//GEN-LAST:event_cityKeyTyped

    private void founderKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_founderKeyTyped
         char c = evt.getKeyChar();
  
        
        if(Character.isLetter(c) || Character.isWhitespace(c) || c=='ñ' || c =='.' || c=='-'){
            
        }else{
              evt.consume(); 
        }
    }//GEN-LAST:event_founderKeyTyped

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
clear();    }//GEN-LAST:event_jButton2ActionPerformed

    private void siKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_siKeyTyped
        char c = evt.getKeyChar();

        if(Character.isDigit(c)){
            if(si.getText().length()==11){
                evt.consume();
            }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_siKeyTyped


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cb;
    private javax.swing.JTextField city;
    private javax.swing.JTextField cn;
    private javax.swing.JTextField date;
    private javax.swing.JTextField founder;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton save;
    private javax.swing.JTextField si;
    private javax.swing.JTable tables;
    // End of variables declaration//GEN-END:variables

  
}
