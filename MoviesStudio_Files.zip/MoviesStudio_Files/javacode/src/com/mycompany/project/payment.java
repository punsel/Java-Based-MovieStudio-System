/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package com.mycompany.project;

import static com.mycompany.project.order.DB_URL;
import static com.mycompany.project.order.PASSWORD;
import static com.mycompany.project.order.USERNAME;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class payment extends javax.swing.JInternalFrame {

        public static final String DB_URL = "jdbc:mysql://localhost/moviestudio";
        public static final String USERNAME = "ms";
        public static final String PASSWORD = "ms";
        
    DefaultTableModel modelorder,modelpayment;
    Object row [][];
    String col[] = {"CUSTOMER ID","MOVIE ID","ORDER ID","MOVIE PRICE","QUANTITY","ORDER DATE"};
    Object row1[][];
    String col1[] = {"CUSTOMER ID","MOVIE ID","ORDER ID","PAYMENT ID","QUANTITY","PRICE","DISCOUNT","TOTAL","PAYED","CHANGE","STATUS"};
   
    
  
    public payment() {
        initComponents();
        initialstate();
        setpaymenttable();
        setordertable();
    }
    
    
     public void initialstate(){
          
      
       
    }
    public void makeinput(){
        save.setEnabled(true);
        
     
    }
    
      public void input(){
      
    }

    
    public void clear(){
        mi.setText("");
        oi.setText("");
        ci.setText("");
        pi.setText("");
        q.setText("");
        oi.setText("");
        p.setText("");
        total.setText("");
        pay.setText("");
      
        
    }
    
      
       public void setordertable(){
           modelorder = new DefaultTableModel(row, col);
        tableo.setModel(modelorder);

          String sql = "SELECT * FROM orderr";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                modelorder.addRow(new Object []{rs.getInt("customer_id"),
                      rs.getInt("movie_id"),
                    rs.getInt("order_id"),
                    rs.getDouble("price"),
                    rs.getInt("quantity"),
                    rs.getString("date")});
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
     }
       
       
         public void setpaymenttable(){
         
           modelpayment = new DefaultTableModel(row1, col1);
        tablep.setModel(modelpayment);
         
         
          String sql = "SELECT * FROM payment";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                modelpayment.addRow(new Object []{rs.getInt("customer_id"),
                    rs.getInt("movie_id"),
                    rs.getInt("order_id"),
                    rs.getInt("payment_id"),
                    rs.getInt("quantity"),
                    rs.getDouble("price"),
                   rs.getDouble("discount"),
                    rs.getDouble("total"),
                      rs.getInt("pay"),
                    rs.getDouble("change"),
                    rs.getString("status")});
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
     }
       
       
        public void getorderdata(){
         int rownumber = tableo.getSelectedRow();
         ci.setText(modelorder.getValueAt(rownumber ,0).toString());
         mi.setText(modelorder.getValueAt(rownumber , 1).toString());
         oi.setText(modelorder.getValueAt(rownumber , 2).toString());
         q.setText(modelorder.getValueAt(rownumber , 4).toString());
         p.setText(modelorder.getValueAt(rownumber ,3).toString());
         
          Double totall = Integer.parseInt(modelorder.getValueAt(rownumber , 4).toString()) * Double.parseDouble(modelorder.getValueAt(rownumber ,3).toString());
        total.setText(""+totall);  
     }
        
         public void addpayment(){
             if(ci.getText().equals("") || mi.getText().equals("") || oi.getText().equals("") || q.getText().equals("") || p.getText().equals("") ){
             JOptionPane.showMessageDialog(null," PLEASE INPUT ALL FIELDS");
         }
             else{
                 
                 int payy = Integer.parseInt(pay.getText());
             Double total = Double.parseDouble(p.getText()) * Integer.parseInt(q.getText());
              
            
                 
             if(total >= 5000){
                 Double dis = total * .1;
                 Double distotal = total - dis;
                 if( payy > distotal){
                 Double change =  Integer.parseInt(pay.getText()) - distotal;
                 
           try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();){
            
            String sql = "INSERT INTO payment VALUES(null,'"+Integer.parseInt(oi.getText())+"','"+Integer.parseInt(ci.getText())+"','"+Integer.parseInt(mi.getText())+"','"+Integer.parseInt(q.getText())+"','"+Double.parseDouble(p.getText())+"','"+dis+"','"+distotal+"','"+Integer.parseInt(pay.getText())+"','"+change+"','SOLD')";
            
                    stmt.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"successfully added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
      }
                 else{
                       JOptionPane.showMessageDialog(null,"NOT ENOUGH,PAREHA NMO");
                 }
    }
             else{
                 Double dis = total * .05;
                 Double distotal = total - dis;
                 if( payy > distotal){
                  Double change =  Integer.parseInt(pay.getText()) - distotal;
                 
           try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();){
            
            String sql = "INSERT INTO payment VALUES(null,'"+Integer.parseInt(oi.getText())+"','"+Integer.parseInt(ci.getText())+"','"+Integer.parseInt(mi.getText())+"','"+Integer.parseInt(q.getText())+"','"+Double.parseDouble(p.getText())+"','"+dis+"','"+distotal+"','"+Integer.parseInt(pay.getText())+"','"+change+"','SOLD')";
            
                    stmt.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"successfully added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
      }      
                 else{
                        JOptionPane.showMessageDialog(null,"NOT ENOUGH,PAREHA NMO");
                 }
    }
           
             }
             
             
         }
         
         
         
          public void getpaymentdata(){
         int rownumber = tablep.getSelectedRow();
         ci.setText(modelpayment.getValueAt(rownumber , 0).toString());
          mi.setText(modelpayment.getValueAt(rownumber , 1).toString());
           oi.setText(modelpayment.getValueAt(rownumber , 2).toString());
            pi.setText(modelpayment.getValueAt(rownumber ,3).toString());
           q.setText(modelpayment.getValueAt(rownumber , 4).toString());
            p.setText(modelpayment.getValueAt(rownumber ,5).toString());
            total.setText(modelpayment.getValueAt(rownumber , 8).toString());
            pay.setText(modelpayment.getValueAt(rownumber ,9).toString());
            
             
     }
         
         
           public void delete(){
               if(tablep.getSelectedRowCount() == 1){
         try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "delete from payment where payment_id = '"+Integer.parseInt(pi.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"succesfully deleted");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
               }
                else{
               if(tablep.getSelectedRowCount() == 0){
                   JOptionPane.showMessageDialog(null,"please select single row to delete");
               }
               else{
                    JOptionPane.showMessageDialog(null,"table is empty");
               }
               }
    }
           
           public void update(){
               
               if(tablep.getSelectedRowCount()==1){
                 int total = Integer.parseInt(p.getText()) * Integer.parseInt(q.getText());
             
             if(total >= 5000){
                 Double dis = total * .1;
                 Double distotal = total - dis;
       
             try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "UPDATE payment SET  order_id = '"+oi.getText()+"',"
                    +"customer_id = '"+ci.getText()+"',"
                     +"movie_id = '"+mi.getText()+"',"
                    + "quantity = '"+q.getText()+"',"
                     + "price = '"+p.getText()+"',"
                     + "discount = '"+dis+"',"
                    + "total = '"+distotal+"'  WHERE payment_id = '"+Integer.parseInt(pi.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"updated added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
             }
    
             
             else{
                 
                Double dis = total * .05;
                 Double distotal = total - dis;
       
             try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "UPDATE payment SET  order_id = '"+oi.getText()+"',"
                    +"customer_id = '"+ci.getText()+"',"
                     +"movie_id = '"+mi.getText()+"',"
                    + "quantity = '"+q.getText()+"',"
                       + "price = '"+p.getText()+"',"
                     + "discount = '"+dis+"',"
                    + "total = '"+distotal+"'  WHERE payment_id = '"+Integer.parseInt(pi.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"updated added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
                 
             }
               }
                else{
               if(tablep.getSelectedRowCount() == 0){
                   JOptionPane.showMessageDialog(null,"please select single row to update");
               }
               else{
                    JOptionPane.showMessageDialog(null,"table is empty");
               }
               }
             
           }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel35 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tabled2 = new javax.swing.JTable();
        jButton18 = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        jButton21 = new javax.swing.JButton();
        jTextField30 = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jTextField34 = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        jTextField31 = new javax.swing.JTextField();
        jButton19 = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabled = new javax.swing.JTable();
        jLabel40 = new javax.swing.JLabel();
        jTextField27 = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        jTextField36 = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jTextField33 = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        tabled1 = new javax.swing.JTable();
        jTextField28 = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jButton20 = new javax.swing.JButton();
        jLabel60 = new javax.swing.JLabel();
        save = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        pay = new javax.swing.JTextField();
        total = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        tablep = new javax.swing.JTable();
        jLabel47 = new javax.swing.JLabel();
        jButton23 = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        jButton24 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        tableo = new javax.swing.JTable();
        jLabel37 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        ci = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        p = new javax.swing.JTextField();
        pi = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        jInternalFrame1 = new javax.swing.JInternalFrame();
        save1 = new javax.swing.JButton();
        jScrollPane10 = new javax.swing.JScrollPane();
        tablep1 = new javax.swing.JTable();
        jLabel49 = new javax.swing.JLabel();
        jButton26 = new javax.swing.JButton();
        jLabel32 = new javax.swing.JLabel();
        jButton27 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jScrollPane11 = new javax.swing.JScrollPane();
        tableo1 = new javax.swing.JTable();
        jLabel52 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        ci1 = new javax.swing.JTextField();
        jLabel55 = new javax.swing.JLabel();
        p1 = new javax.swing.JTextField();
        pi1 = new javax.swing.JTextField();
        jLabel56 = new javax.swing.JLabel();
        mi1 = new javax.swing.JTextField();
        jLabel57 = new javax.swing.JLabel();
        q1 = new javax.swing.JTextField();
        oi1 = new javax.swing.JTextField();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        mi = new javax.swing.JTextField();
        jLabel50 = new javax.swing.JLabel();
        q = new javax.swing.JTextField();
        oi = new javax.swing.JTextField();
        jLabel51 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        jLabel35.setBackground(new java.awt.Color(255, 255, 255));
        jLabel35.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(51, 51, 51));
        jLabel35.setText("MOVIE ID:");

        tabled2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane7.setViewportView(tabled2);

        jButton18.setBackground(new java.awt.Color(0, 0, 0));
        jButton18.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton18.setForeground(new java.awt.Color(204, 255, 255));
        jButton18.setText("SAVE");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jLabel38.setBackground(new java.awt.Color(255, 255, 255));
        jLabel38.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(51, 51, 51));
        jLabel38.setText("STUDIO ID:");

        jButton21.setBackground(new java.awt.Color(0, 0, 0));
        jButton21.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 255, 255));
        jButton21.setText("UPDATE");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        jLabel43.setBackground(new java.awt.Color(255, 255, 255));
        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(51, 51, 51));
        jLabel43.setText("STATUS:");

        jLabel39.setBackground(new java.awt.Color(255, 255, 255));
        jLabel39.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(51, 51, 51));
        jLabel39.setText("DIRECTOR TABLE");

        jLabel41.setBackground(new java.awt.Color(255, 255, 255));
        jLabel41.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(51, 51, 51));
        jLabel41.setText("STUDIO TABLE");

        jButton19.setBackground(new java.awt.Color(0, 0, 0));
        jButton19.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton19.setForeground(new java.awt.Color(255, 255, 255));
        jButton19.setText("NEW");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        tabled.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(tabled);

        jLabel40.setBackground(new java.awt.Color(255, 255, 255));
        jLabel40.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(51, 51, 51));
        jLabel40.setText("MOVIE TITTLE:");

        jLabel45.setBackground(new java.awt.Color(255, 255, 255));
        jLabel45.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(51, 51, 51));
        jLabel45.setText("PRICE:");

        jLabel36.setBackground(new java.awt.Color(255, 255, 255));
        jLabel36.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(51, 51, 51));
        jLabel36.setText("DIRECTOR ID:");

        tabled1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(tabled1);

        jLabel42.setBackground(new java.awt.Color(255, 255, 255));
        jLabel42.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(51, 51, 51));
        jLabel42.setText("CATEGORY:");

        jLabel30.setBackground(new java.awt.Color(0, 0, 0));
        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(51, 51, 51));
        jLabel30.setText("MOVIE");

        jButton20.setBackground(new java.awt.Color(0, 0, 0));
        jButton20.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton20.setForeground(new java.awt.Color(255, 255, 255));
        jButton20.setText("DELETE");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        jLabel60.setBackground(new java.awt.Color(255, 255, 255));
        jLabel60.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(255, 255, 255));
        jLabel60.setText("PAYMENT ID:");

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        save.setBackground(new java.awt.Color(0, 0, 0));
        save.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        save.setForeground(new java.awt.Color(204, 255, 255));
        save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/heroicons-solid--save (1).png"))); // NOI18N
        save.setText("SAVE");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        getContentPane().add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, 100, 40));

        jButton2.setText("clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 20, 60, -1));
        getContentPane().add(pay, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 310, 60, -1));
        getContentPane().add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 260, 60, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("PAY:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 290, -1, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("TOTAL:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 240, -1, 20));

        tablep.setBackground(new java.awt.Color(204, 204, 204));
        tablep.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tablep.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablep.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablepMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(tablep);

        getContentPane().add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 230, 710, 120));

        jLabel47.setBackground(new java.awt.Color(255, 255, 255));
        jLabel47.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setText("PAYMENT TABLE");
        getContentPane().add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 210, -1, -1));

        jButton23.setBackground(new java.awt.Color(0, 0, 0));
        jButton23.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton23.setForeground(new java.awt.Color(255, 255, 255));
        jButton23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/typcn--plus (1).png"))); // NOI18N
        jButton23.setText("NEW");
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, 100, 40));

        jLabel31.setBackground(new java.awt.Color(0, 0, 0));
        jLabel31.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("PAYMENT");
        getContentPane().add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        jButton24.setBackground(new java.awt.Color(0, 0, 0));
        jButton24.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton24.setForeground(new java.awt.Color(255, 255, 255));
        jButton24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/mingcute--delete-fill.png"))); // NOI18N
        jButton24.setText("DELETE");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 200, 40));

        jButton25.setBackground(new java.awt.Color(0, 0, 0));
        jButton25.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton25.setForeground(new java.awt.Color(255, 255, 255));
        jButton25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/dashicons--update.png"))); // NOI18N
        jButton25.setText("UPDATE");
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 200, 40));

        tableo.setBackground(new java.awt.Color(204, 204, 204));
        tableo.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tableo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tableo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableoMouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(tableo);

        getContentPane().add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 40, 710, 160));

        jLabel37.setBackground(new java.awt.Color(255, 255, 255));
        jLabel37.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("MOVIE ID:");
        getContentPane().add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, -1, 40));

        jLabel44.setBackground(new java.awt.Color(255, 255, 255));
        jLabel44.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setText("CUSTOMER ID:");
        getContentPane().add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 90, 20));

        ci.setEditable(false);
        ci.setBackground(new java.awt.Color(153, 153, 153));
        getContentPane().add(ci, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 50, 110, -1));

        jLabel46.setBackground(new java.awt.Color(255, 255, 255));
        jLabel46.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 255, 255));
        jLabel46.setText("PRICE:");
        getContentPane().add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, -1, 20));

        p.setEditable(false);
        p.setBackground(new java.awt.Color(153, 153, 153));
        getContentPane().add(p, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 110, -1));

        pi.setEditable(false);
        pi.setBackground(new java.awt.Color(153, 204, 255));
        pi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                piKeyTyped(evt);
            }
        });
        getContentPane().add(pi, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 200, 110, -1));

        jLabel48.setBackground(new java.awt.Color(255, 255, 255));
        jLabel48.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 255, 255));
        jLabel48.setText("PAYMENT ID:");
        getContentPane().add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, 20));

        jInternalFrame1.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        save1.setBackground(new java.awt.Color(0, 0, 0));
        save1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        save1.setForeground(new java.awt.Color(204, 255, 255));
        save1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/heroicons-solid--save (1).png"))); // NOI18N
        save1.setText("SAVE");
        save1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save1ActionPerformed(evt);
            }
        });
        jInternalFrame1.getContentPane().add(save1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 240, 100, 40));

        tablep1.setBackground(new java.awt.Color(204, 204, 204));
        tablep1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tablep1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablep1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablep1MouseClicked(evt);
            }
        });
        jScrollPane10.setViewportView(tablep1);

        jInternalFrame1.getContentPane().add(jScrollPane10, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 230, 710, 120));

        jLabel49.setBackground(new java.awt.Color(255, 255, 255));
        jLabel49.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(255, 255, 255));
        jLabel49.setText("PAYMENT TABLE");
        jInternalFrame1.getContentPane().add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 210, -1, -1));

        jButton26.setBackground(new java.awt.Color(0, 0, 0));
        jButton26.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton26.setForeground(new java.awt.Color(255, 255, 255));
        jButton26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/typcn--plus (1).png"))); // NOI18N
        jButton26.setText("NEW");
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });
        jInternalFrame1.getContentPane().add(jButton26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 100, 40));

        jLabel32.setBackground(new java.awt.Color(0, 0, 0));
        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("PAYMENT");
        jInternalFrame1.getContentPane().add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        jButton27.setBackground(new java.awt.Color(0, 0, 0));
        jButton27.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton27.setForeground(new java.awt.Color(255, 255, 255));
        jButton27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/mingcute--delete-fill.png"))); // NOI18N
        jButton27.setText("DELETE");
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });
        jInternalFrame1.getContentPane().add(jButton27, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 200, 40));

        jButton28.setBackground(new java.awt.Color(0, 0, 0));
        jButton28.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton28.setForeground(new java.awt.Color(255, 255, 255));
        jButton28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/dashicons--update.png"))); // NOI18N
        jButton28.setText("UPDATE");
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });
        jInternalFrame1.getContentPane().add(jButton28, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 200, 40));

        tableo1.setBackground(new java.awt.Color(204, 204, 204));
        tableo1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tableo1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tableo1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableo1MouseClicked(evt);
            }
        });
        jScrollPane11.setViewportView(tableo1);

        jInternalFrame1.getContentPane().add(jScrollPane11, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 40, 710, 160));

        jLabel52.setBackground(new java.awt.Color(255, 255, 255));
        jLabel52.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(255, 255, 255));
        jLabel52.setText("MOVIE ID:");
        jInternalFrame1.getContentPane().add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, -1, 40));

        jLabel54.setBackground(new java.awt.Color(255, 255, 255));
        jLabel54.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel54.setForeground(new java.awt.Color(255, 255, 255));
        jLabel54.setText("CUSTOMER ID:");
        jInternalFrame1.getContentPane().add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, 40));

        ci1.setBackground(new java.awt.Color(204, 204, 204));
        jInternalFrame1.getContentPane().add(ci1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 60, 110, -1));

        jLabel55.setBackground(new java.awt.Color(255, 255, 255));
        jLabel55.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(255, 255, 255));
        jLabel55.setText("PRICE:");
        jInternalFrame1.getContentPane().add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, -1, 20));

        p1.setBackground(new java.awt.Color(204, 204, 204));
        jInternalFrame1.getContentPane().add(p1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 180, 110, -1));

        pi1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                pi1KeyTyped(evt);
            }
        });
        jInternalFrame1.getContentPane().add(pi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, 110, -1));

        jLabel56.setBackground(new java.awt.Color(255, 255, 255));
        jLabel56.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(255, 255, 255));
        jLabel56.setText("PAYMENT ID:");
        jInternalFrame1.getContentPane().add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, -1, 20));

        mi1.setBackground(new java.awt.Color(204, 204, 204));
        jInternalFrame1.getContentPane().add(mi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 90, 110, -1));

        jLabel57.setBackground(new java.awt.Color(255, 255, 255));
        jLabel57.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(255, 255, 255));
        jLabel57.setText("ORDER ID:");
        jInternalFrame1.getContentPane().add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, -1, 40));

        q1.setBackground(new java.awt.Color(204, 204, 204));
        jInternalFrame1.getContentPane().add(q1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 110, -1));

        oi1.setBackground(new java.awt.Color(204, 204, 204));
        jInternalFrame1.getContentPane().add(oi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, 110, -1));

        jLabel58.setBackground(new java.awt.Color(255, 255, 255));
        jLabel58.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(255, 255, 255));
        jLabel58.setText(" QUANTITY:");
        jInternalFrame1.getContentPane().add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, -1, 40));

        jLabel59.setBackground(new java.awt.Color(255, 255, 255));
        jLabel59.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(255, 255, 255));
        jLabel59.setText("ORDER TABLE");
        jInternalFrame1.getContentPane().add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 20, -1, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\OIP (5).jpg")); // NOI18N
        jLabel3.setText("jLabel1");
        jInternalFrame1.getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 250, 390));

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\4441226.jpg")); // NOI18N
        jLabel4.setText("jLabel2");
        jInternalFrame1.getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, 820, 390));

        jButton3.setText("clear");
        jInternalFrame1.getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 60, -1));

        getContentPane().add(jInternalFrame1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        mi.setEditable(false);
        mi.setBackground(new java.awt.Color(153, 153, 153));
        getContentPane().add(mi, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 110, -1));

        jLabel50.setBackground(new java.awt.Color(255, 255, 255));
        jLabel50.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(255, 255, 255));
        jLabel50.setText("ORDER ID:");
        getContentPane().add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, 70, 40));

        q.setEditable(false);
        q.setBackground(new java.awt.Color(153, 153, 153));
        getContentPane().add(q, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 140, 110, -1));

        oi.setEditable(false);
        oi.setBackground(new java.awt.Color(153, 153, 153));
        getContentPane().add(oi, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, 110, -1));

        jLabel51.setBackground(new java.awt.Color(255, 255, 255));
        jLabel51.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(255, 255, 255));
        jLabel51.setText(" QUANTITY:");
        getContentPane().add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, -1, 40));

        jLabel53.setBackground(new java.awt.Color(255, 255, 255));
        jLabel53.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(255, 255, 255));
        jLabel53.setText("ORDER TABLE");
        getContentPane().add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 20, -1, -1));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\OIP (5).jpg")); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 250, 390));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\4441226.jpg")); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, 820, 390));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton20ActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
       addpayment();
       setpaymenttable();
       clear();
    }//GEN-LAST:event_saveActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
       makeinput();
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
       delete();
       setpaymenttable();
       clear();
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
      pi.setEditable(false);
        update();
        setpaymenttable();
        clear();
    }//GEN-LAST:event_jButton25ActionPerformed

    private void tableoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableoMouseClicked

        getorderdata();
       
    }//GEN-LAST:event_tableoMouseClicked

    private void tablepMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablepMouseClicked
      getpaymentdata();
     input();
    }//GEN-LAST:event_tablepMouseClicked

    private void piKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_piKeyTyped
      char c = evt.getKeyChar();
        
        if(Character.isDigit(c)){
            if(pi.getText().length()==11){
                evt.consume();
            }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_piKeyTyped

    private void save1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_save1ActionPerformed

    private void tablep1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablep1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tablep1MouseClicked

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton27ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton28ActionPerformed

    private void tableo1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableo1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tableo1MouseClicked

    private void pi1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pi1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_pi1KeyTyped

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       clear();
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ci;
    private javax.swing.JTextField ci1;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton3;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTextField jTextField27;
    private javax.swing.JTextField jTextField28;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTextField jTextField31;
    private javax.swing.JTextField jTextField33;
    private javax.swing.JTextField jTextField34;
    private javax.swing.JTextField jTextField36;
    private javax.swing.JTextField mi;
    private javax.swing.JTextField mi1;
    private javax.swing.JTextField oi;
    private javax.swing.JTextField oi1;
    private javax.swing.JTextField p;
    private javax.swing.JTextField p1;
    private javax.swing.JTextField pay;
    private javax.swing.JTextField pi;
    private javax.swing.JTextField pi1;
    private javax.swing.JTextField q;
    private javax.swing.JTextField q1;
    private javax.swing.JButton save;
    private javax.swing.JButton save1;
    private javax.swing.JTable tabled;
    private javax.swing.JTable tabled1;
    private javax.swing.JTable tabled2;
    private javax.swing.JTable tableo;
    private javax.swing.JTable tableo1;
    private javax.swing.JTable tablep;
    private javax.swing.JTable tablep1;
    private javax.swing.JTextField total;
    // End of variables declaration//GEN-END:variables
}
