/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package com.mycompany.project;


import static com.mycompany.project.order.DB_URL;
import static com.mycompany.project.order.PASSWORD;
import static com.mycompany.project.order.USERNAME;
import static com.mycompany.project.studio.DB_URL;
import static com.mycompany.project.studio.PASSWORD;
import static com.mycompany.project.studio.USERNAME;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class movie extends javax.swing.JInternalFrame {
    
   
      public static final String DB_URL = "jdbc:mysql://localhost/moviestudio";
      public static final String USERNAME = "ms";
      public static final String PASSWORD = "ms";
        
 DefaultTableModel modelstudio,modeldirector,modelmovie;
    Object row [][];
    String col[] = {"STUDIO ID","COMPANY NAME","COMPANY TYPE","CITY","DATE FOUNDED","FOUNDER"};
    Object row1[][];
    String col1[] = {"MOVIE ID","DIRECTOR ID","STUDIO ID","MOVIE TITTLE","CATEGORY","STATUS","PRICE"};
      Object row2 [][];
    String col2[] = {"DIRECTOR ID","FULL NAME","GENDER","NATIONALITY","AGE","CONTACT NUMBER"};
    private int id;
  
     
    
    
    
    public movie() {
        initComponents();
       
        setmovietable();
        setstudiotable();
        setdirectortable();

    }

    
   
    public void makeinput(){
         save.setEnabled(true);
          cbc.setEnabled(true);
           cbs.setEnabled(true);
        mt.setEditable(true);
        p.setEditable(true);
    }
    
    public void clear(){
        di.setText("");
        mi.setText("");
        si.setText("");
        mt.setText("");
        cbc.setSelectedIndex(-1);
        cbs.setSelectedIndex(-1);
        p.setText("");
    
    }
    
     public void input(){
        mt.setEditable(true);
      cbc.setEnabled(true);
      cbs.setEnabled(true);
        p.setEditable(true);
    }
    
    
    
    
    public void addmovie(){
        
          if(di.getText().equals("") ||si.getText().equals("") || mt.getText().equals("") || p.getText().equals("")){
             JOptionPane.showMessageDialog(null," PLEASE INPUT ALL FIELDS");
         }
          else{
              
               String category  = (String) cbc.getItemAt(cbc.getSelectedIndex());
                String status  = (String) cbs.getItemAt(cbs.getSelectedIndex());
           try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();){
            
            String sql = "INSERT INTO movie VALUES(null,'"+Integer.parseInt(di.getText())+"','"+Integer.parseInt(si.getText())+"','"+mt.getText()+"','"+category+"','"+status+"','"+Double.parseDouble(p.getText())+"')";
            
                    stmt.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"successfully added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
          }
    }
    
    
    
      public void setmovietable(){
          modelmovie = new DefaultTableModel(row1, col1);
        tablem.setModel(modelmovie);
        
          String sql = "SELECT * FROM movie";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                modelmovie.addRow(new Object []{rs.getInt("movie_id"),
                    rs.getInt("director_id"),
                    rs.getInt("studio_id"),
                    rs.getString("tittle"),
                    rs.getString("category"),
                    rs.getString("status"),
                    rs.getDouble("price")});
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
}
      
       public void setstudiotable(){
      modelstudio = new DefaultTableModel(row, col);
        tables.setModel(modelstudio);
        
         String sql = "SELECT * FROM studio";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                modelstudio.addRow(new Object []{rs.getInt("studio_id"),rs.getString("company_name"),rs.getString("company_type"),rs.getString("city"),rs.getString("date"),rs.getString("founder")});
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
}
       
        public void setdirectortable(){
      modeldirector = new DefaultTableModel(row2, col2);
        tabled.setModel(modeldirector);
        
        String sql = "select * from director";
        try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                modeldirector.addRow(new Object[]{rs.getInt("director_id"),rs.getString("name"),rs.getString("gender"),rs.getString("nationality"), rs.getInt("age"),rs.getString("number")});
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        }
       

        public void getmoviedata(){
         int rownumber = tablem.getSelectedRow();
         mi.setText(modelmovie.getValueAt(rownumber , 0).toString());
          di.setText(modelmovie.getValueAt(rownumber , 1).toString());
           si.setText(modelmovie.getValueAt(rownumber ,2).toString());
           mt.setText(modelmovie.getValueAt(rownumber , 3).toString());
            cbc.setSelectedItem(modelmovie.getValueAt(rownumber ,4).toString());
             cbs.setSelectedItem(modelmovie.getValueAt(rownumber , 5).toString());
              p.setText(modelmovie.getValueAt(rownumber ,6).toString());
         
     }
        
        
        public void delete(){
            if(tablem.getSelectedRowCount()== 1){
         try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "delete from movie where movie_id = '"+Integer.parseInt(mi.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"succesfully deleted");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
            }
             else{
               if(tablem.getSelectedRowCount() == 0){
                   JOptionPane.showMessageDialog(null,"please select single row to delete");
               }
               else{
                    JOptionPane.showMessageDialog(null,"table is empty");
               }
               }
            
    }
        
        
         
    public void update(){
       if(tablem.getSelectedRowCount()==1){
           
            String category  = (String) cbc.getItemAt(cbc.getSelectedIndex());
                String status  = (String) cbs.getItemAt(cbs.getSelectedIndex());
                
             try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "UPDATE movie SET  director_id = '"+di.getText()+"',"
                    +"studio_id = '"+si.getText()+"',"
                    + "tittle = '"+mt.getText()+"',"
                    + "status = '"+status+"',"
                    + "category = '"+category+"',"
                    + " price= '"+p.getText()+"' WHERE movie_id = '"+Integer.parseInt(mi.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"updated added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
             
                
              String sql = "SELECT * FROM orderr";
        try(Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                
              int id = rs.getInt("order_id");
            String sql1 = "UPDATE orderr SET price= '"+p.getText()+"' WHERE order_id = '"+id+"'";
            stmt.executeUpdate(sql1);
            JOptionPane.showMessageDialog(null,"updated added");
            }
            
        }catch(SQLException ex){
            ex.printStackTrace();
        }
             
             
   
       }
        else{
               if(tabled.getSelectedRowCount() == 0){
                   JOptionPane.showMessageDialog(null,"please select single row to update");
               }
               else{
                    JOptionPane.showMessageDialog(null,"table is empty");
               }
               }
    }
    
    
   
        
        
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel37 = new javax.swing.JLabel();
        jTextField29 = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        jTextField35 = new javax.swing.JTextField();
        cbs = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jLabel35 = new javax.swing.JLabel();
        save = new javax.swing.JButton();
        mi = new javax.swing.JTextField();
        cbc = new javax.swing.JComboBox<>();
        jLabel30 = new javax.swing.JLabel();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabled = new javax.swing.JTable();
        jLabel36 = new javax.swing.JLabel();
        di = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        si = new javax.swing.JTextField();
        mt = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        p = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        tablem = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        tables = new javax.swing.JTable();
        jLabel39 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        jLabel37.setBackground(new java.awt.Color(255, 255, 255));
        jLabel37.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(51, 51, 51));
        jLabel37.setText("CUSTOMER ID");

        jLabel44.setBackground(new java.awt.Color(255, 255, 255));
        jLabel44.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(51, 51, 51));
        jLabel44.setText("STATUS:");

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cbs.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "Now showing", "Recently Released", "Limited Release", "Out of Theaters" }));
        getContentPane().add(cbs, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, 110, -1));

        jButton2.setText("clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, 60, -1));

        jLabel35.setBackground(new java.awt.Color(255, 255, 255));
        jLabel35.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("MOVIE ID:");
        getContentPane().add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, 20));

        save.setBackground(new java.awt.Color(0, 0, 0));
        save.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        save.setForeground(new java.awt.Color(255, 255, 255));
        save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/heroicons-solid--save (1).png"))); // NOI18N
        save.setText("SAVE");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        getContentPane().add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 210, -1));

        mi.setEditable(false);
        mi.setBackground(new java.awt.Color(153, 204, 255));
        mi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                miKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                miKeyTyped(evt);
            }
        });
        getContentPane().add(mi, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 110, -1));

        cbc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "Drama", "Horror", "Lovestory", "Comedy", "Adventure" }));
        getContentPane().add(cbc, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, 110, -1));

        jLabel30.setBackground(new java.awt.Color(0, 0, 0));
        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("MOVIE");
        getContentPane().add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        jButton20.setBackground(new java.awt.Color(0, 0, 0));
        jButton20.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton20.setForeground(new java.awt.Color(255, 255, 255));
        jButton20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/mingcute--delete-fill.png"))); // NOI18N
        jButton20.setText("DELETE");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 210, -1));

        jButton21.setBackground(new java.awt.Color(0, 0, 0));
        jButton21.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 255, 255));
        jButton21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/dashicons--update.png"))); // NOI18N
        jButton21.setText("UPDATE");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 310, 210, -1));

        tabled.setBackground(new java.awt.Color(204, 204, 204));
        tabled.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tabled.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabled.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabledMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tabled);

        getContentPane().add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 210, 380, 150));

        jLabel36.setBackground(new java.awt.Color(255, 255, 255));
        jLabel36.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("DIRECTOR ID:");
        getContentPane().add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, 20));

        di.setEditable(false);
        di.setBackground(new java.awt.Color(153, 153, 153));
        getContentPane().add(di, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 40, 110, -1));

        jLabel38.setBackground(new java.awt.Color(255, 255, 255));
        jLabel38.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("  STUDIO ID:");
        getContentPane().add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        si.setEditable(false);
        si.setBackground(new java.awt.Color(153, 153, 153));
        getContentPane().add(si, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 110, -1));

        mt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                mtKeyPressed(evt);
            }
        });
        getContentPane().add(mt, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 110, -1));

        jLabel40.setBackground(new java.awt.Color(255, 255, 255));
        jLabel40.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("MOVIE TITTLE:");
        getContentPane().add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, -1, 20));

        jLabel42.setBackground(new java.awt.Color(255, 255, 255));
        jLabel42.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("CATEGORY:");
        getContentPane().add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, 30));

        jLabel43.setBackground(new java.awt.Color(255, 255, 255));
        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("STATUS:");
        getContentPane().add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, -1, 30));

        jLabel45.setBackground(new java.awt.Color(255, 255, 255));
        jLabel45.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setText("PRICE:");
        getContentPane().add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, -1, 30));

        p.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                pKeyTyped(evt);
            }
        });
        getContentPane().add(p, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, 110, -1));

        tablem.setBackground(new java.awt.Color(204, 204, 204));
        tablem.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tablem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablemMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(tablem);

        getContentPane().add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 16, 800, 170));

        tables.setBackground(new java.awt.Color(204, 204, 204));
        tables.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tables.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tables.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablesMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(tables);

        getContentPane().add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 210, 410, 150));

        jLabel39.setBackground(new java.awt.Color(255, 255, 255));
        jLabel39.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("DIRECTOR TABLE");
        getContentPane().add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 190, -1, -1));

        jLabel41.setBackground(new java.awt.Color(255, 255, 255));
        jLabel41.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("STUDIO TABLE");
        getContentPane().add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 190, -1, -1));

        jLabel46.setBackground(new java.awt.Color(255, 255, 255));
        jLabel46.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 255, 255));
        jLabel46.setText("MOVIE TABLE");
        getContentPane().add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(574, 0, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\OIP (5).jpg")); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 410));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\4441226.jpg")); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, 860, 380));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        addmovie();
       setmovietable();
       // setdirectortable();
        //setstudiotable();
        clear();
    }//GEN-LAST:event_saveActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        delete();
        setmovietable();
        clear();
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
      update();
      setmovietable();
      clear();
    }//GEN-LAST:event_jButton21ActionPerformed

    private void tablesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablesMouseClicked
      int rownumber = tables.getSelectedRow();
        si.setText(modelstudio.getValueAt(rownumber , 0).toString());
    }//GEN-LAST:event_tablesMouseClicked

    private void tabledMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabledMouseClicked
        int rownumber = tabled.getSelectedRow();
        di.setText(modeldirector.getValueAt(rownumber , 0).toString());
    }//GEN-LAST:event_tabledMouseClicked

    private void tablemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablemMouseClicked
input();
getmoviedata();
     
    }//GEN-LAST:event_tablemMouseClicked

    private void miKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_miKeyPressed
      

    }//GEN-LAST:event_miKeyPressed

    private void mtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mtKeyPressed
        
    }//GEN-LAST:event_mtKeyPressed

    private void miKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_miKeyTyped
        char c = evt.getKeyChar();
        
        if(Character.isDigit(c)){
            if(si.getText().length()==11){
                evt.consume();
            }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_miKeyTyped

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      clear();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void pKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pKeyTyped
        char c = evt.getKeyChar();

        if(Character.isDigit(c) || c=='.' ){
            if(p.getText().length()==11){
                evt.consume();
            }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_pKeyTyped

    private void pKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pKeyPressed

    }//GEN-LAST:event_pKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbc;
    private javax.swing.JComboBox<String> cbs;
    private javax.swing.JTextField di;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTextField jTextField29;
    private javax.swing.JTextField jTextField35;
    private javax.swing.JTextField mi;
    private javax.swing.JTextField mt;
    private javax.swing.JTextField p;
    private javax.swing.JButton save;
    private javax.swing.JTextField si;
    private javax.swing.JTable tabled;
    private javax.swing.JTable tablem;
    private javax.swing.JTable tables;
    // End of variables declaration//GEN-END:variables

    void setLocationRelativeTo(movie m) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
