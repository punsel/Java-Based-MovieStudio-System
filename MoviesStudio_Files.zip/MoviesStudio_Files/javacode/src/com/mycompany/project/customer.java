/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package com.mycompany.project;

import static com.mycompany.project.actor.PASSWORD;
import static com.mycompany.project.actor.USERNAME;
import static com.mycompany.project.director.DB_URL;
import static com.mycompany.project.director.USERNAME;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class customer extends javax.swing.JInternalFrame {

    
     public static final String DB_URL = "jdbc:mysql://localhost/moviestudio";
      public static final String USERNAME = "ms";
        public static final String PASSWORD = "ms";
    DefaultTableModel modelcustomer;
    Object row [][];
    String col[] = {"CUSTOMER ID","NAME","GENDER","AGE","CONTACT NUMBER","EMAIL ADDRESS"};
   
   
    public customer() {
        initComponents();
        setcustomertable();
        initialstate();
    }
   
    
     public void initialstate(){
        save.setEnabled(false);
        fn.setEditable(false);
        age.setEditable(false);
       cn.setEditable(false);
    email.setEditable(false);
       
    }
    public void makeinput(){
         save.setEnabled(true);
        fn.setEditable(true);
        age.setEditable(true);
       cn.setEditable(true);
    email.setEditable(true);
    }
    
    public void clear(){
        ci.setText("");
       fn.setText("");
       age.setText("");
        cn.setText("");
        email.setText("");
        buttonGroup1.clearSelection();
    }
    
    
    
    public void addcustomer(){
        if(fn.getText().equals("") || age.getText().equals("") || cn.getText().equals("") || email.getText().equals("")){
             JOptionPane.showMessageDialog(null," PLEASE INPUT ALL FIELDS");
         }
        else{
        try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String gender;
            if(male.isSelected()){
                gender = " Male";
            }
            else{
              gender = "Female";
            }

            String sql = " insert into customer values(null,"
                    + "'"+fn.getText()+"','"+ gender +"','"+age.getText()+"','"+cn.getText()+"','"+email.getText()+"')";
                    stmt.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null,"successfully added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        }
    }

    
     public void setcustomertable(){
      modelcustomer = new DefaultTableModel(row, col);
        tablec.setModel(modelcustomer);
        
         String sql = "select * from customer";
        try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);){
            while(rs.next()){
                modelcustomer.addRow(new Object[]{rs.getInt("customer_id"),
                    rs.getString("name"),
                    rs.getString("gender"),
                    rs.getInt("age"),
                    rs.getString("number")
                        ,rs.getString("email")});
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
}
     
     
     
      public void getcustomerdata(){
         int rownumber = tablec.getSelectedRow();
         
         ci.setText(modelcustomer.getValueAt(rownumber , 0).toString());
          fn.setText(modelcustomer.getValueAt(rownumber , 1).toString());
         
         
            age.setText(modelcustomer.getValueAt(rownumber , 3).toString());
             cn.setText(modelcustomer.getValueAt(rownumber , 4).toString());
              email.setText(modelcustomer.getValueAt(rownumber ,5).toString());
              
                String gender =  modelcustomer.getValueAt(rownumber , 2).toString();
               if(gender.equals("Female")){
                   female.setSelected(true);
               }
               else{
                    male.setSelected(true);
               }
         
     }
      
      
        public void delete(){
            if(tablec.getSelectedRowCount() == 1){
         try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "delete from customer where customer_id = '"+Integer.parseInt(ci.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"succesfully deleted");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
            }
             else{
               if(tablec.getSelectedRowCount() == 0){
                   JOptionPane.showMessageDialog(null,"please select single row to delete");
               }
               else{
                    JOptionPane.showMessageDialog(null,"table is empty");
               }
               }
    }
        
        public void update(){
        if(tablec.getSelectedRowCount()==1){
         String gender;
            if(male.isSelected()){
                gender = " Male";
            }
            else{
              gender = "Female";
            }
             try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
                Statement stmt = conn.createStatement();){
            String sql = "UPDATE customer SET name = '"+fn.getText()+"', gender = '"+gender+"',age= '"+age.getText()+"',number = '"+cn.getText()+"',email = '"+email.getText()+"' WHERE customer_id = '"+Integer.parseInt(ci.getText())+"'";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"updated added");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        }
         else{
               if(tablec.getSelectedRowCount() == 0){
                   JOptionPane.showMessageDialog(null,"please select single row to update");
               }
               else{
                    JOptionPane.showMessageDialog(null,"table is empty");
               }
               }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel35 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel32 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        save = new javax.swing.JButton();
        female = new javax.swing.JRadioButton();
        male = new javax.swing.JRadioButton();
        jButton19 = new javax.swing.JButton();
        ci = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        email = new javax.swing.JTextField();
        age = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jButton20 = new javax.swing.JButton();
        fn = new javax.swing.JTextField();
        jButton21 = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tablec = new javax.swing.JTable();
        cn = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel35.setBackground(new java.awt.Color(255, 255, 255));
        jLabel35.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("CUSTOMER ID:");
        getContentPane().add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 54, -1, -1));

        jButton2.setText("clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, 60, -1));

        jLabel32.setBackground(new java.awt.Color(255, 255, 255));
        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("GENDER:");
        getContentPane().add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(55, 109, -1, -1));

        jLabel36.setBackground(new java.awt.Color(255, 255, 255));
        jLabel36.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("EMAIL ADDRESS:");
        getContentPane().add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, -1, -1));

        save.setBackground(new java.awt.Color(0, 0, 0));
        save.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        save.setForeground(new java.awt.Color(204, 255, 255));
        save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/heroicons-solid--save (1).png"))); // NOI18N
        save.setText("SAVE");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        getContentPane().add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, 110, 40));

        buttonGroup1.add(female);
        female.setForeground(new java.awt.Color(255, 255, 255));
        female.setText("Female");
        getContentPane().add(female, new org.netbeans.lib.awtextra.AbsoluteConstraints(168, 105, -1, -1));

        buttonGroup1.add(male);
        male.setForeground(new java.awt.Color(255, 255, 255));
        male.setText("Male");
        male.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maleActionPerformed(evt);
            }
        });
        getContentPane().add(male, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 105, -1, -1));

        jButton19.setBackground(new java.awt.Color(0, 0, 0));
        jButton19.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton19.setForeground(new java.awt.Color(255, 255, 255));
        jButton19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/typcn--plus (1).png"))); // NOI18N
        jButton19.setText("NEW");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton19, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 110, 40));

        ci.setEditable(false);
        ci.setBackground(new java.awt.Color(153, 204, 255));
        ci.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ciKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ciKeyTyped(evt);
            }
        });
        getContentPane().add(ci, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 49, 115, -1));

        jLabel33.setBackground(new java.awt.Color(255, 255, 255));
        jLabel33.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("AGE:");
        getContentPane().add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(79, 133, -1, 23));

        email.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                emailKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                emailKeyTyped(evt);
            }
        });
        getContentPane().add(email, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 190, 115, -1));

        age.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ageKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ageKeyTyped(evt);
            }
        });
        getContentPane().add(age, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 132, 115, -1));

        jLabel30.setBackground(new java.awt.Color(0, 0, 0));
        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("CUSTOMER");
        getContentPane().add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, -1));

        jButton20.setBackground(new java.awt.Color(0, 0, 0));
        jButton20.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton20.setForeground(new java.awt.Color(255, 255, 255));
        jButton20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/mingcute--delete-fill.png"))); // NOI18N
        jButton20.setText("DELETE");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 223, 40));

        fn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                fnKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                fnKeyTyped(evt);
            }
        });
        getContentPane().add(fn, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 77, 115, -1));

        jButton21.setBackground(new java.awt.Color(0, 0, 0));
        jButton21.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 255, 255));
        jButton21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/dashicons--update.png"))); // NOI18N
        jButton21.setText("UPDATE");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 223, 40));

        jLabel31.setBackground(new java.awt.Color(255, 255, 255));
        jLabel31.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("FULL NAME:");
        getContentPane().add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 82, -1, -1));

        jLabel34.setBackground(new java.awt.Color(255, 255, 255));
        jLabel34.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("CONTACT NO:");
        getContentPane().add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 167, -1, -1));

        tablec.setBackground(new java.awt.Color(204, 204, 204));
        tablec.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tablec.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablec.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablecMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tablec);

        getContentPane().add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 40, 720, 300));

        cn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cnKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cnKeyTyped(evt);
            }
        });
        getContentPane().add(cn, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 162, 115, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\OIP (5).jpg")); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, 380));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\4441226.jpg")); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 830, 380));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        addcustomer();
        setcustomertable();
        clear();
    }//GEN-LAST:event_saveActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
       makeinput();
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
   delete();
   setcustomertable();
   clear();
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
       update();
       setcustomertable();
       clear();
    }//GEN-LAST:event_jButton21ActionPerformed

    private void tablecMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablecMouseClicked
getcustomerdata();    }//GEN-LAST:event_tablecMouseClicked


    private void maleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_maleActionPerformed

    private void emailKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_emailKeyPressed
       
    }//GEN-LAST:event_emailKeyPressed

    private void ciKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ciKeyPressed
       

    }//GEN-LAST:event_ciKeyPressed

    private void ageKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ageKeyPressed
      

    }//GEN-LAST:event_ageKeyPressed

    private void cnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnKeyPressed
      

    }//GEN-LAST:event_cnKeyPressed

    private void fnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fnKeyPressed
    
    }//GEN-LAST:event_fnKeyPressed

    private void ciKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ciKeyTyped
       char c = evt.getKeyChar();
        
        if(Character.isDigit(c)){
            if(ci.getText().length()==11){
                evt.consume();
            }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_ciKeyTyped

    private void fnKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fnKeyTyped
          char c = evt.getKeyChar();
  
        
        if(Character.isLetter(c) || Character.isWhitespace(c) || c=='ñ' || c =='.' || c=='-'){
            
        }else{
              evt.consume(); 
        }
    }//GEN-LAST:event_fnKeyTyped

    private void ageKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ageKeyTyped
        char c = evt.getKeyChar();
        
        if(Character.isDigit(c)){
            if(age.getText().length()==3){
                evt.consume();
            }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_ageKeyTyped

    private void cnKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnKeyTyped
           char c = evt.getKeyChar();
        
        if(Character.isDigit(c)){
            if(cn.getText().length()==11){
                evt.consume();
            }
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_cnKeyTyped

    private void emailKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_emailKeyTyped
         char c = evt.getKeyChar();
        if(Character.isDigit(c) || Character.isLetter(c) || c=='@' || c=='.' || c=='-' || c=='_'){
          
        }else{
            evt.consume();
        }
    }//GEN-LAST:event_emailKeyTyped

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      clear();
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField age;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField ci;
    private javax.swing.JTextField cn;
    private javax.swing.JTextField email;
    private javax.swing.JRadioButton female;
    private javax.swing.JTextField fn;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JRadioButton male;
    private javax.swing.JButton save;
    private javax.swing.JTable tablec;
    // End of variables declaration//GEN-END:variables
}
